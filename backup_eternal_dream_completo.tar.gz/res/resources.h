#ifndef _RES_RESOURCES_H_
#define _RES_RESOURCES_H_

extern const u8 sfx_laser[1792];
extern const u8 sfx_wide[2304];
extern const u8 sfx_fast[1536];
extern const u8 sfx_missile[2816];
extern const u8 sfx_boom[4608];
extern const u8 sfx_start[5120];
extern const u8 mus_titulo[1024];
extern const u8 mus_hangar[1024];
extern const u8 mus_juego[1024];
extern const u8 mus_jefe[2048];
extern const u8 mus_victoria[768];
extern const Image img_titulo_ov;
extern const SpriteDefinition spr_nave;
extern const SpriteDefinition spr_nave_r;
extern const SpriteDefinition spr_nave_a;
extern const SpriteDefinition spr_enemigo1;
extern const SpriteDefinition spr_enemigo2;
extern const SpriteDefinition spr_laser;
extern const SpriteDefinition spr_pwr;
extern const SpriteDefinition spr_escudo;
extern const SpriteDefinition spr_exp;
extern const Image img_fondo;
extern const Image img_tierra;
extern const Image img_altura;
extern const Image img_ptop;
extern const Image img_pmid;
extern const Image img_pbot;
extern const Image img_s1_top;
extern const Image img_s1_mid;
extern const Image img_s1_bot;
extern const Image img_s2_top;
extern const Image img_s2_mid;
extern const Image img_s2_bot;
extern const Image img_s3_top;
extern const Image img_s3_mid;
extern const Image img_s3_bot;
extern const SpriteDefinition spr_jefe1;
extern const SpriteDefinition spr_bala_jefe;
extern const Image img_estrato;
extern const SpriteDefinition spr_jefe2;
extern const SpriteDefinition spr_jefe3;
extern const Image img_ftop;
extern const Image img_fmid;
extern const Image img_fbot;

#endif // _RES_RESOURCES_H_
